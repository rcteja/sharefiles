package com.spring.mvcwoa.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.spring.mvcwoa.bean.LoginBean;


@Controller
public class LoginController {

	@RequestMapping(value="/login", method=RequestMethod.GET)
	public ModelAndView loginAuth(@ModelAttribute("loginBean") LoginBean loginBean  ,HttpSession httpSession){
		//String emailId= params.get("p");
		//String userName= params.get("userName");
		httpSession.setAttribute("userName", loginBean.getUserName());
		ModelAndView mav = new ModelAndView("redirect:/viewemp");
		return mav;		
	}
	
	@RequestMapping(value="/loginPage", method=RequestMethod.GET)
	public ModelAndView loginPage(){
		ModelAndView mav = new ModelAndView("login");
		mav.addObject("loginBean", new LoginBean());
		return mav;		
	}
	
}

package com.spring.mvcwoa.dao;
import java.util.ArrayList;
import java.util.List;

import com.spring.mvcwoa.bean.Emp;

public class EmpDao {


public List<Emp> save(Emp p){
	List<Emp> list=getEmployees();
			list.add(p);
	//String sql="insert into Emp99(name,salary,designation) values('"+p.getName()+"',"+p.getSalary()+",'"+p.getDesignation()+"')";
	
	return list;
}
public int update(Emp p){

	//String sql="update Emp99 set name='"+p.getName()+"', salary="+p.getSalary()+", designation='"+p.getDesignation()+"' where id="+p.getId()+"";
	return 1;
}
public int delete(int id){

	return 1;
	//String sql="delete from Emp99 where id="+id+"";
}
public Emp getEmpById(int id){
	List<Emp> list=getEmployees();
	for(Emp emp:list){
		if(emp.getEmpid()==id){
			return emp	;
		}
	}
	
	return null;
}
public  List<Emp> getEmployees(){
	 List<Emp> list =new ArrayList<Emp>();

	list.add(new Emp(123,"Ramcharan",60000,"analyst"));
	list.add(new Emp(147,"Teja",70000,"tech lead"));;
	return list;
	
}
}

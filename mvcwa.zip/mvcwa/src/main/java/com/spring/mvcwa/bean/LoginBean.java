package com.spring.mvcwa.bean;


public class LoginBean {
	private String userName;
	private char[] pwd;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public char[] getPwd() {
		return pwd;
	}
	public void setPwd(char[] pwd) {
		this.pwd = pwd;
	}
	
	
}

